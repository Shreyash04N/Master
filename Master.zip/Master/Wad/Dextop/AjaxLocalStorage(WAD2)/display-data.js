$(document).ready(function () {
  getData();
});

function getData() {
  let localStorageData = localStorage.getItem("student");
  let studentObj = JSON.parse(localStorageData);
 
  $("#firstName").text(studentObj.firstName);
  $("#lastName").text(studentObj.lastName);
  $("#gender").text(studentObj.gender);
  $("#email").text(studentObj.email);
  $("#contactNo").text(studentObj.contactNo);
  $("#branch").text(studentObj.branch);
  $("#registrationDate").text(studentObj.registrationDate);
}

function getCon(){
  let localStorageData = localStorage.getItem("student");
  let studentObj = JSON.parse(localStorageData);
  
}
