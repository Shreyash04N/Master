$(document).ready(function () {


  $("#btnAddStudent").click(function () {

    function getStudentData() {
      let date = new Date($("#dob").val());
      day = date.getDate();
      month = date.getMonth() + 1;
      year = date.getFullYear();
      let dob = [day, month, year].join("/");

      let selectedDate = new Date($("#registrationDate").val());
      day = selectedDate.getDate()+1;
      month = selectedDate.getMonth() + 1;
      year = selectedDate.getFullYear();
      let registrationDate = [day, month, year].join("/");
      console.log(registrationDate);

      let student = {
        firstName: $("#firstName").val(),
        lastName: $("#lastName").val(),
        gender: $("input[name='gender']:checked").val(),
        email: $("#email").val(),
        contactNo: $("#contactNo").val(),
        registrationDate: registrationDate,
      };
      return student;
    }


    function storeDataToLocalStorage() {
      if (!localStorage.getItem("student")) {
        localStorage.setItem("student", JSON.stringify(getStudentData()));
      } else {
        localStorage.removeItem("student");
        localStorage.setItem("student", JSON.stringify(getStudentData()));
      }
      sendData();
    }

 
    function sendData() {
      let xhr = new XMLHttpRequest();
      let data = JSON.stringify(getStudentData());
      let local = localStorage.getItem('student');
     
      xhr.open("POST", "response.txt",true);
      xhr.setRequestHeader("Content-Type", "application/json");
      xhr.send(data);
      prompt(local);
    }

  
    storeDataToLocalStorage();
   
      window.location.href="display-data.html"
  });
});
